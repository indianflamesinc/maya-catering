'use client'
// src/app/admin/enquiries/[id]/page.tsx
// FIX-007 (Jun 15 2026): Labour $0 hidden in quote summary
// FIX-069 (Jun 16 2026): customerPhone prop passed to SendReviewButton — WhatsApp anchor link restored
// FIX-074 (Jun 16 2026): Quote badge derives from enquiry.status — no longer stuck at DRAFT
// FIX-075 (Jun 16 2026): Send Quote button hidden at approved/deposit_paid/confirmed stages
// FIX-067 (Jun 16 2026): Quote status updates when enquiry advances
//   BEFORE: quote badge stayed 'DRAFT' even after deposit paid / confirmed
//   AFTER:  advanceStatus() also PATCHes latest quote status to 'approved' or 'sent'
// FIX-068 (Jun 16 2026): Send Quote button hidden after deposit paid
//   BEFORE: 'Send Quote for Customer Review' showed at all stages including deposit_paid
//   AFTER:  hidden when status is approved/deposit_paid/confirmed/completed/cancelled — was always showing $0.00
//   BEFORE: Labour stat card rendered unconditionally even when labour_cents=0
//   AFTER:  Labour card only renders when labour_cents > 0
// FIX-016 (Jun 15 2026): 'Mark Deposit Received' button in quick action bar
//   BEFORE: No button to advance approved→deposit_paid for Zelle/Check payments
//   AFTER:  Button appears when enquiry.status==='approved'
// FIX-034 (Jun 15 2026): customerPhone/customerName props passed to ReviewRoundsPanel
//   BEFORE: WhatsApp button in panel had no phone number
//   AFTER:  Props passed from enquiry so WhatsApp opens pre-filled
import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import { ArrowLeft, Phone, Mail, Calendar, Users, MapPin, ChefHat, FileText, DollarSign, ClipboardList } from 'lucide-react'
import { Enquiry, LeadStatus, LEAD_STATUS_LABELS, STATUS_COLORS, EVENT_TYPE_LABELS, EventType } from '@/types/crm'
import { SendReviewButton } from '@/components/crm/SendReviewButton'
import { ReviewRoundsPanel } from '@/components/crm/ReviewRoundsPanel'

const fmt = (c: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(c / 100)

function InfoRow({ label, value }: { label: string; value?: string | number | null }) {
  if (!value) return null
  return (
    <div className="grid grid-cols-[140px_1fr] gap-3 py-2.5 border-b border-gold/10 last:border-b-0">
      <span className="font-cinzel text-[8px] tracking-[0.22em] uppercase text-gold/60">{label}</span>
      <span className="text-cream/80 text-[13px]">{value}</span>
    </div>
  )
}

const PIPELINE = [
  { status: 'new',          label: 'New',          action: 'Contact Customer',   icon: '📞' },
  { status: 'contacted',    label: 'Contacted',    action: 'Build Quote',        icon: '📄' },
  { status: 'tasting',      label: 'Tasting',      action: 'After Tasting',      icon: '🍽️' },
  { status: 'quoted',       label: 'Quoted',       action: 'Awaiting Response',  icon: '⏳' },
  { status: 'negotiating',  label: 'Negotiating',  action: 'Revise Quote',       icon: '🤝' },
  { status: 'approved',     label: 'Approved',     action: 'Collect Deposit',    icon: '✅' },
  { status: 'deposit_paid', label: 'Deposit Paid', action: 'Send Contract',      icon: '💰' },
  { status: 'confirmed',    label: 'Confirmed',    action: 'Prep Kitchen List',  icon: '🎉' },
  { status: 'completed',    label: 'Completed',    action: 'Request Review',     icon: '⭐' },
]

const NEXT_STATUS: Partial<Record<LeadStatus, LeadStatus>> = {
  new: 'contacted', contacted: 'quoted', tasting: 'quoted',
  quoted: 'negotiating', negotiating: 'approved',
  approved: 'deposit_paid', deposit_paid: 'confirmed', confirmed: 'completed',
}

const NEXT_LABEL: Partial<Record<LeadStatus, string>> = {
  new: '📞 Mark Contacted', contacted: '📄 Mark Quoted',
  tasting: '📄 Mark Quoted', quoted: '🤝 Negotiating',
  negotiating: '✅ Mark Approved', approved: '💰 Deposit Paid',
  deposit_paid: '🎉 Mark Confirmed', confirmed: '⭐ Mark Completed',
}

export default function EnquiryDetailPage() {
  const { id } = useParams<{ id: string }>()
  const router = useRouter()
  const [enquiry, setEnquiry] = useState<Enquiry | null>(null)
  const [quotes, setQuotes] = useState<any[]>([])
  const [reviewRounds, setReviewRounds] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [updating, setUpdating] = useState(false)

  useEffect(() => { load() }, [id])

  async function load() {
    const [eRes, qRes, rRes] = await Promise.all([
      fetch(`/api/enquiries/${id}`),
      fetch(`/api/quotes?enquiry_id=${id}`),
      fetch(`/api/quotes/review-rounds?enquiry_id=${id}`),
    ])
    const eData = await eRes.json()
    const qData = await qRes.json()
    const rData = await rRes.json()
    setEnquiry(eData)
    setQuotes(qData.quotes || [])
    setReviewRounds(rData.rounds || [])
    setLoading(false)
  }

  async function advanceStatus() {
    if (!enquiry) return
    const next = NEXT_STATUS[enquiry.status]
    if (!next) return
    setUpdating(true)
    const res = await fetch(`/api/enquiries/${id}`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: next }),
    })
    setEnquiry(await res.json())

    // FIX-067 (Jun 16 2026): Update latest quote status when enquiry advances
    // BEFORE: quote badge stayed 'draft' even after deposit paid / confirmed
    // AFTER:  quote status updates to match enquiry stage
    if (quotes.length > 0) {
      const quoteStatus =
        next === 'deposit_paid' || next === 'confirmed' || next === 'completed' ? 'approved' :
        next === 'quoted' ? 'sent' : 'draft'
      await fetch(`/api/quotes/${quotes[0].id}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: quoteStatus }),
      })
    }

    setUpdating(false)
  }

  async function markCancelled() {
    if (!confirm('Mark as cancelled?')) return
    setUpdating(true)
    const res = await fetch(`/api/enquiries/${id}`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'cancelled' }),
    })
    setEnquiry(await res.json())
    setUpdating(false)
  }

  if (loading) return <div className="min-h-screen bg-ink flex items-center justify-center"><p className="font-italiana text-[28px] text-cream/30">Loading...</p></div>
  if (!enquiry) return <div className="min-h-screen bg-ink flex items-center justify-center"><p className="font-italiana text-[28px] text-cream/30">Not found</p></div>

  const latestQuote = quotes[0]
  const daysUntil = Math.ceil((new Date(enquiry.event_date).getTime() - Date.now()) / 86400000)
  const statusIdx = PIPELINE.findIndex(p => p.status === enquiry.status)

  return (
    <div className="min-h-screen bg-ink">
      {/* Header */}
      <div className="bg-royal-mid border-b border-gold/20 px-8 py-5">
        <div className="flex items-center gap-4 mb-5">
          <Link href="/admin/enquiries" className="text-gold/50 hover:text-gold transition-colors"><ArrowLeft size={20} /></Link>
          <div className="flex-1">
            <span className="font-cinzel text-[8px] tracking-[0.4em] uppercase text-gold block mb-0.5">Enquiry Detail</span>
            <h1 className="font-italiana text-[36px] text-cream leading-none">{enquiry.customer_name}</h1>
          </div>
          <span className={`font-cinzel text-[8px] tracking-[0.2em] uppercase border px-4 py-2 ${STATUS_COLORS[enquiry.status] || ''}`}>
            {LEAD_STATUS_LABELS[enquiry.status]}
          </span>
          {NEXT_STATUS[enquiry.status] && (
            <button onClick={advanceStatus} disabled={updating}
              className="font-cinzel text-[8px] tracking-[0.2em] uppercase bg-gold text-ink px-5 py-2.5 hover:bg-gold-hi transition-colors disabled:opacity-40">
              {updating ? '...' : NEXT_LABEL[enquiry.status]}
            </button>
          )}
        </div>

        {/* Status pipeline */}
        <div className="flex items-center gap-0 overflow-x-auto pb-1">
          {PIPELINE.map((step, i) => {
            const isDone = i < statusIdx
            const isCurrent = i === statusIdx
            return (
              <div key={step.status} className="flex items-center flex-shrink-0">
                <div className={`flex flex-col items-center px-3 py-2 min-w-[80px] text-center ${isCurrent ? 'opacity-100' : isDone ? 'opacity-60' : 'opacity-25'}`}>
                  <span className="text-lg mb-1">{step.icon}</span>
                  <span className={`font-cinzel text-[7px] tracking-[0.12em] uppercase ${isCurrent ? 'text-gold' : 'text-cream/60'}`}>{step.label}</span>
                  {isCurrent && <span className="text-[9px] text-gold/60 mt-0.5">{step.action}</span>}
                </div>
                {i < PIPELINE.length - 1 && (
                  <div className={`w-6 h-0.5 flex-shrink-0 ${i < statusIdx ? 'bg-gold/40' : 'bg-gold/10'}`} />
                )}
              </div>
            )
          })}
        </div>
      </div>

      {/* Quick action bar */}
      <div className="bg-royal border-b border-gold/10 px-8 py-3 flex gap-3 flex-wrap">
        <Link href={`/admin/enquiries/${id}/quote`}
          className="font-cinzel text-[7.5px] tracking-[0.2em] uppercase border border-gold/30 text-gold px-4 py-2 hover:bg-gold/10 transition-colors flex items-center gap-2">
          <FileText size={12} /> {quotes.length > 0 ? `View/Edit Quote (v${latestQuote?.version})` : 'Build Quote'}
        </Link>
        <Link href={`/admin/enquiries/${id}/tasting`}
          className="font-cinzel text-[7.5px] tracking-[0.2em] uppercase border border-gold/30 text-gold px-4 py-2 hover:bg-gold/10 transition-colors flex items-center gap-2">
          <ChefHat size={12} /> Schedule Tasting
        </Link>
        <a href={`tel:${enquiry.customer_phone}`}
          className="font-cinzel text-[7.5px] tracking-[0.2em] uppercase border border-gold/30 text-gold px-4 py-2 hover:bg-gold/10 transition-colors flex items-center gap-2">
          <Phone size={12} /> Call {enquiry.customer_phone}
        </a>
        {enquiry.customer_email && (
          <a href={`mailto:${enquiry.customer_email}`}
            className="font-cinzel text-[7.5px] tracking-[0.2em] uppercase border border-gold/30 text-gold px-4 py-2 hover:bg-gold/10 transition-colors flex items-center gap-2">
            <Mail size={12} /> Email Customer
          </a>
        )}
        {['confirmed','deposit_paid','approved'].includes(enquiry.status) && (
          <Link href={`/admin/enquiries/${id}/kitchen`}
            className="font-cinzel text-[7.5px] tracking-[0.2em] uppercase border border-green-500/40 text-green-400 px-4 py-2 hover:bg-green-500/10 transition-colors flex items-center gap-2">
            <ClipboardList size={12} /> Kitchen Prep List
          </Link>
        )}
        {/* FIX-016 (Jun 15 2026): Mark Deposit Received button
           BEFORE: no way to advance from approved→deposit_paid without going through main advance button
           AFTER: dedicated button in action bar when status=approved for Zelle/Check payment confirmation */}
        {enquiry.status === 'approved' && (
          <button onClick={advanceStatus} disabled={updating}
            className="font-cinzel text-[7.5px] tracking-[0.2em] uppercase border border-green-500/40 text-green-400 px-4 py-2 hover:bg-green-500/10 transition-colors flex items-center gap-2 ml-auto">
            💰 Mark Deposit Received
          </button>
        )}
        <button onClick={markCancelled} disabled={updating || enquiry.status === 'cancelled'}
          className="font-cinzel text-[7.5px] tracking-[0.2em] uppercase border border-red-500/20 text-red-400/60 px-4 py-2 hover:bg-red-500/10 transition-colors ml-auto disabled:opacity-20">
          Cancel Enquiry
        </button>
      </div>

      <div className="max-w-[1200px] mx-auto px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-8">
          <div className="flex flex-col gap-6">

            {/* Quote summary */}
            {latestQuote && (
              <div className="border border-gold/30 bg-gold/5 p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className="font-cinzel text-[9px] tracking-[0.35em] uppercase text-gold">Latest Quote — Version {latestQuote.version}</span>
                  {/* FIX-074 (Jun 16 2026): Badge reflects actual state — not just quote.status
                       BEFORE: always showed 'draft' because quote.status not updated until deposit_paid
                       AFTER:  derives badge from enquiry.status when past negotiating stage */}
                  {(() => {
                    const enqStatus = enquiry.status
                    const derivedStatus = ['approved','deposit_paid','confirmed','completed'].includes(enqStatus)
                      ? enqStatus.replace('_',' ')
                      : latestQuote.status
                    const badgeClass = ['approved','deposit paid','confirmed','completed'].includes(derivedStatus)
                      ? 'border-green-500/40 text-green-400 bg-green-500/10'
                      : latestQuote.status === 'sent'
                      ? 'border-blue-500/40 text-blue-400 bg-blue-500/10'
                      : 'border-gold/20 text-gold/60'
                    return (
                      <span className={`font-cinzel text-[7.5px] tracking-[0.15em] uppercase border px-2 py-1 ${badgeClass}`}>
                        {derivedStatus}
                      </span>
                    )
                  })()}
                </div>

                {/* FIX-007 (Jun 15 2026): hide Labour when $0 — was showing $0.00 cluttering the summary */}
                <div className="grid grid-cols-4 gap-4 mb-4">
                  {[
                    { l: 'Food Subtotal', v: fmt(latestQuote.subtotal_cents || 0) },
                    // FIX-007: only show Labour if > 0
                    ...(latestQuote.labour_cents > 0 ? [{ l: 'Labour', v: fmt(latestQuote.labour_cents) }] : []),
                    { l: 'Tax (7%)', v: fmt(latestQuote.tax_cents || 0) },
                    { l: 'Grand Total', v: fmt(latestQuote.total_cents || 0), gold: true },
                  ].map(item => (
                    <div key={item.l}>
                      <span className="font-cinzel text-[7.5px] tracking-[0.18em] uppercase text-gold/50 block mb-1">{item.l}</span>
                      <span className={`font-italiana text-[22px] leading-none ${item.gold ? 'text-gold-hi' : 'text-cream'}`}>{item.v}</span>
                    </div>
                  ))}
                </div>

                {latestQuote.total_cents > 0 && (
                  <div className="flex gap-6 text-[12px] text-cream/50 border-t border-gold/10 pt-3">
                    <span>20% Deposit: <strong className="text-cream/70">{fmt(Math.round(latestQuote.total_cents * 0.2))}</strong></span>
                    <span>Balance (3 days before): <strong className="text-cream/70">{fmt(latestQuote.total_cents - Math.round(latestQuote.total_cents * 0.2))}</strong></span>
                    <span>Catering type: <strong className="text-cream/70 capitalize">{latestQuote.catering_type?.replace('_',' ')}</strong></span>
                  </div>
                )}

                <div className="flex items-center gap-4 mt-4 flex-wrap">
                  <Link href={`/admin/enquiries/${id}/quote`}
                    className="font-cinzel text-[7.5px] tracking-[0.2em] uppercase border border-gold/30 text-gold px-4 py-2 hover:bg-gold/10 transition-colors">
                    Open Quote Builder →
                  </Link>
                  {/* FIX-075 (Jun 16 2026): Hide Send Quote button at approved/deposit_paid/confirmed stages
                       BEFORE: button showed at all stages including after deposit paid
                       AFTER:  hidden when enquiry is approved, deposit_paid, confirmed, completed, cancelled */}
                  {enquiry.customer_email && !['approved','deposit_paid','confirmed','completed','cancelled'].includes(enquiry.status) && (
                    <SendReviewButton
                      enquiryId={enquiry.id}
                      quoteId={latestQuote.id}
                      customerName={enquiry.customer_name}
                      customerEmail={enquiry.customer_email}
                      customerPhone={enquiry.customer_phone}
                    />
                  )}
                </div>
                {/* FIX-076b (Jun 17 2026): pass customerPhone+customerName to ReviewRoundsPanel
                     BEFORE: props missing → getWhatsAppUrl() returns null → WhatsApp button never shows
                     AFTER:  props passed → WhatsApp <a href> renders on every round row */}
                <ReviewRoundsPanel
                  enquiryId={enquiry.id}
                  quoteId={latestQuote.id}
                  onRoundUpdate={load}
                  customerPhone={enquiry.customer_phone}
                  customerName={enquiry.customer_name}
                />
              </div>
            )}

            {/* Sessions */}
            {latestQuote?.quote_sessions?.length > 0 && (
              <div className="border border-gold/20 bg-royal-mid p-6">
                <span className="font-cinzel text-[9px] tracking-[0.35em] uppercase text-gold block mb-5">Event Sessions</span>
                <div className="flex flex-col gap-3">
                  {latestQuote.quote_sessions.map((sess: any, i: number) => (
                    <div key={sess.id} className="border border-gold/10 bg-royal p-4">
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-italiana text-[20px] text-cream">{sess.session_name || `Session ${i+1}`}</span>
                        <span className="text-gold-hi font-italiana text-[18px]">
                          {fmt((sess.quote_session_categories || []).reduce((s: number, c: any) => s + (sess.guest_count * (c.price_per_person || 0)), 0))}
                        </span>
                      </div>
                      <div className="flex gap-4 text-[12px] text-cream/50 mb-3">
                        <span>👥 {sess.guest_count} guests</span>
                        {sess.price_per_person && <span>💰 ${(sess.price_per_person/100).toFixed(2)}/person</span>}
                      </div>
                      {(sess.quote_session_categories || []).map((cat: any) => (
                        <div key={cat.id} className="mb-2">
                          <div className="flex justify-between text-[11px] mb-1">
                            <span className="text-gold/60 font-cinzel tracking-wider uppercase text-[7.5px]">{cat.category_name}</span>
                            <span className="text-cream/50">${(cat.price_per_person/100).toFixed(2)}/pp × {sess.guest_count} = {fmt(sess.guest_count * cat.price_per_person)}</span>
                          </div>
                          {(cat.quote_session_dishes || []).map((dish: any) => (
                            <div key={dish.id} className="text-[12px] text-cream/60 pl-3 py-0.5 flex items-center gap-2">
                              <span className="text-gold/20">•</span>{dish.dish_name}
                              {dish.is_live_station && <span className="text-amber-400/70 text-[9px] font-cinzel tracking-wider uppercase">Live</span>}
                              {dish.is_passing && <span className="text-blue-400/70 text-[9px] font-cinzel tracking-wider uppercase">Passing</span>}
                            </div>
                          ))}
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Tray items */}
            {latestQuote?.quote_tray_items?.length > 0 && (
              <div className="border border-gold/20 bg-royal-mid p-6">
                <span className="font-cinzel text-[9px] tracking-[0.35em] uppercase text-gold block mb-4">Tray Order Items</span>
                <div className="grid grid-cols-[2fr_100px_60px_80px_100px] gap-2 mb-2 px-2">
                  {['Dish','Size','Qty','Unit','Total'].map(h => (
                    <span key={h} className="font-cinzel text-[7px] tracking-[0.15em] uppercase text-gold/40">{h}</span>
                  ))}
                </div>
                {latestQuote.quote_tray_items.map((item: any) => (
                  <div key={item.id} className="grid grid-cols-[2fr_100px_60px_80px_100px] gap-2 px-2 py-2 border-t border-gold/10 text-[13px]">
                    <span className="text-cream">{item.dish_name}</span>
                    <span className="text-cream/50 capitalize">
                      {item.pricing_type === 'per_person' ? 'Per Person' :
                       item.pricing_type === 'per_piece'  ? 'Per Piece'  :
                       item.pricing_type === 'per_gallon' ? 'Per Gallon' :
                       item.pricing_type === 'per_portion'? 'Per Portion':
                       item.tray_size === 'half'   ? 'Small' :
                       item.tray_size === 'medium' ? 'Medium' :
                       item.tray_size === 'custom' ? 'Multiple' : 'Full Tray'}
                    </span>
                    <span className="text-cream/50">
                      {item.pricing_type === 'per_person' ? item.guest_count :
                       item.pricing_type === 'per_piece' || item.pricing_type === 'per_gallon' || item.pricing_type === 'per_portion' ? item.piece_count :
                       item.tray_size === 'custom' ? item.tray_quantity : 1}
                    </span>
                    <span className="text-cream/50">{fmt(item.unit_price_cents)}</span>
                    <span className="text-gold-hi">{fmt(item.total_price_cents)}</span>
                  </div>
                ))}
              </div>
            )}

            {!latestQuote && (
              <div className="border border-dashed border-gold/20 p-8 text-center">
                <p className="font-italiana text-[24px] text-cream/30 mb-2">No quote yet</p>
                <p className="text-cream/20 text-[13px] mb-5">Build a quote for this enquiry to see pricing and menu here.</p>
                <Link href={`/admin/enquiries/${id}/quote`} className="btn-royal inline-flex items-center gap-2">
                  <FileText size={14} /> Build Quote Now
                </Link>
              </div>
            )}

            {/* Customer + Event details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="border border-gold/20 bg-royal-mid p-6">
                <div className="flex items-center gap-3 mb-4"><Phone size={14} className="text-gold" /><span className="font-cinzel text-[9px] tracking-[0.35em] uppercase text-gold">Customer</span></div>
                <InfoRow label="Name" value={enquiry.customer_name} />
                <InfoRow label="Phone" value={enquiry.customer_phone} />
                <InfoRow label="Email" value={enquiry.customer_email} />
                <InfoRow label="Source" value={enquiry.heard_about?.replace(/_/g,' ')} />
                <InfoRow label="Referred by" value={enquiry.referred_by} />
              </div>
              <div className="border border-gold/20 bg-royal-mid p-6">
                <div className="flex items-center gap-3 mb-4"><Calendar size={14} className="text-gold" /><span className="font-cinzel text-[9px] tracking-[0.35em] uppercase text-gold">Event</span></div>
                <InfoRow label="Type" value={EVENT_TYPE_LABELS[enquiry.event_type as EventType]} />
                <InfoRow label="Date" value={new Date(enquiry.event_date + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })} />
                <InfoRow label="Time" value={enquiry.event_time} />
                <InfoRow label="Guests" value={`${enquiry.guest_count} guests`} />
                {enquiry.budget_min && <InfoRow label="Budget" value={`$${enquiry.budget_min?.toLocaleString()}${enquiry.budget_max ? ` – $${enquiry.budget_max.toLocaleString()}` : '+'}`} />}
              </div>
            </div>

            {enquiry.venue_name && (
              <div className="border border-gold/20 bg-royal-mid p-6">
                <div className="flex items-center gap-3 mb-4"><MapPin size={14} className="text-gold" /><span className="font-cinzel text-[9px] tracking-[0.35em] uppercase text-gold">Venue</span></div>
                <InfoRow label="Venue" value={enquiry.venue_name} />
                <InfoRow label="Address" value={enquiry.venue_address} />
              </div>
            )}

            {((enquiry.cuisine_preferences?.length ?? 0) > 0 || enquiry.dietary_restrictions || enquiry.special_requirements) && (
              <div className="border border-gold/20 bg-royal-mid p-6">
                <div className="flex items-center gap-3 mb-4"><ChefHat size={14} className="text-gold" /><span className="font-cinzel text-[9px] tracking-[0.35em] uppercase text-gold">Menu Preferences</span></div>
                {(enquiry.cuisine_preferences?.length ?? 0) > 0 && (
                  <div className="mb-4">
                    <span className="font-cinzel text-[7.5px] tracking-[0.2em] uppercase text-gold/50 block mb-2">Cuisines</span>
                    <div className="flex flex-wrap gap-2">
                      {enquiry.cuisine_preferences?.map((c: string) => (
                        <span key={c} className="font-cinzel text-[7.5px] tracking-[0.15em] uppercase border border-gold/20 text-gold px-2 py-1">{c}</span>
                      ))}
                    </div>
                  </div>
                )}
                <InfoRow label="Dietary" value={enquiry.dietary_restrictions} />
                <InfoRow label="Special" value={enquiry.special_requirements} />
              </div>
            )}
          </div>

          {/* RIGHT */}
          <div className="flex flex-col gap-4">
            <div className={`border p-5 text-center ${daysUntil <= 7 ? 'border-red-500/40 bg-red-500/5' : daysUntil <= 30 ? 'border-amber-500/40 bg-amber-500/5' : 'border-gold/20 bg-royal-mid'}`}>
              <span className="font-italiana text-[60px] text-cream block leading-none">{daysUntil > 0 ? daysUntil : 0}</span>
              <span className="font-cinzel text-[8px] tracking-[0.3em] uppercase text-gold">days until event</span>
              {daysUntil <= 7 && daysUntil > 0 && <p className="text-red-400 text-[11px] mt-1">⚡ This week!</p>}
            </div>

            {statusIdx < PIPELINE.length - 1 && (
              <div className="border border-gold/20 bg-royal-mid p-5">
                <span className="font-cinzel text-[8px] tracking-[0.3em] uppercase text-gold block mb-3">Next Step</span>
                <div className="text-[13px] text-cream/70 leading-relaxed">
                  {enquiry.status === 'new' && '📞 Call the customer back to discuss their event requirements and confirm interest.'}
                  {enquiry.status === 'contacted' && '📄 Build a quote using the Quote Builder. Choose per-person or tray pricing based on the event type.'}
                  {enquiry.status === 'tasting' && '🍽️ After the food tasting, update the menu based on feedback and build the final quote.'}
                  {enquiry.status === 'quoted' && '⏳ Waiting for customer to review their online quote. Follow up if no response in 3 days.'}
                  {enquiry.status === 'negotiating' && '🤝 Customer has requested changes. Update the quote and save as a new version.'}
                  {enquiry.status === 'approved' && '💰 Awaiting deposit. Customer has chosen their payment method. Click "Mark Deposit Received" once payment arrives.'}
                  {enquiry.status === 'deposit_paid' && '🎉 Deposit received. Send signed contract. One week before — reconfirm final menu and guest count.'}
                  {enquiry.status === 'confirmed' && '📋 Generate the kitchen prep list. Confirm all staff and logistics one week before the event.'}
                  {enquiry.status === 'completed' && '⭐ Send a review request SMS to the customer with your Google review link.'}
                </div>
              </div>
            )}

            <div className="border border-gold/20 bg-royal-mid p-5">
              <span className="font-cinzel text-[8px] tracking-[0.3em] uppercase text-gold block mb-3">Internal Notes</span>
              {enquiry.internal_notes
                ? <p className="text-cream/70 text-[13px] leading-relaxed">{enquiry.internal_notes}</p>
                : <p className="text-cream/25 text-[12px] italic">No internal notes.</p>
              }
            </div>

            <div className="border border-gold/20 bg-royal-mid p-5">
              <span className="font-cinzel text-[8px] tracking-[0.3em] uppercase text-gold block mb-3">Assignment</span>
              <InfoRow label="Assigned to" value={enquiry.assigned_to} />
              {enquiry.follow_up_date && (
                <InfoRow label="Follow up" value={new Date(enquiry.follow_up_date + 'T12:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })} />
              )}
            </div>

            <div className="border border-gold/20 bg-royal-mid p-5">
              <span className="font-cinzel text-[8px] tracking-[0.3em] uppercase text-gold block mb-3">Record Info</span>
              <InfoRow label="Created" value={new Date(enquiry.created_at).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' })} />
              <InfoRow label="Updated" value={new Date(enquiry.updated_at).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' })} />
              <InfoRow label="Quote versions" value={quotes.length > 0 ? `${quotes.length} version${quotes.length > 1 ? 's' : ''}` : 'No quotes yet'} />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
