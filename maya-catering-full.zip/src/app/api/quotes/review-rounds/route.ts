// src/app/api/quotes/review-rounds/route.ts
// GET — returns all quote_review_tokens for an enquiry ordered by round_number
// Used by: ReviewRoundsPanel (admin CRM), Reply Builder (admin), Quote Builder (FIX-011 customer feedback)
// Status values: pending | viewed | pending_maya | pending_customer | accepted | expired
// SQL constraint updated Jun 16 2026 to include pending_maya and pending_customer
import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  const enquiry_id = req.nextUrl.searchParams.get('enquiry_id')
  if (!enquiry_id) return NextResponse.json({ rounds: [] })

  const { data, error } = await supabase
    .from('quote_review_tokens')
    .select('*')
    .eq('enquiry_id', enquiry_id)
    .order('round_number', { ascending: true })

  if (error) return NextResponse.json({ rounds: [], error: error.message })
  return NextResponse.json({ rounds: data || [] })
}
